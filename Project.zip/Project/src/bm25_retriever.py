from rank_bm25 import BM25Okapi


class BM25Retriever:
    """
    BM25 기반 baseline 검색기.
    """

    def __init__(self, chunks: list[dict]):
        self.chunks = chunks
        self.tokenized_corpus = [
            self._tokenize(chunk.get("chunk_text", ""))
            for chunk in chunks
        ]
        self.bm25 = BM25Okapi(self.tokenized_corpus)

    def _tokenize(self, text: str) -> list[str]:
        """
        1차 구현에서는 공백 기반 토큰화를 사용한다.
        한국어 품질 개선은 2주차 이후 형태소 분석기로 확장 가능하다.
        """
        return str(text).split()

    def search(self, query: str, top_k: int = 10) -> list[dict]:
        if not query.strip():
            return []

        tokenized_query = self._tokenize(query)
        scores = self.bm25.get_scores(tokenized_query)

        ranked_indices = sorted(
            range(len(scores)),
            key=lambda i: scores[i],
            reverse=True
        )[:top_k]

        results = []

        for index in ranked_indices:
            chunk = self.chunks[index]

            results.append({
                "chunk_id": chunk.get("chunk_id"),
                "score": float(scores[index]),
                "section_type": chunk.get("section_type"),
                "retriever": "bm25",
                "preview": chunk.get("chunk_text", "")[:250],
                "chunk_text": chunk.get("chunk_text", ""),
            })

        return results