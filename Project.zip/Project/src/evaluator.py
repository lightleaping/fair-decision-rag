from src.utils import load_jsonl


def load_qa_eval_set(file_path: str) -> list[dict]:
    """
    QA 검증셋을 JSONL 형식으로 불러온다.
    """
    return load_jsonl(file_path)


def calculate_recall_at_5(
    retrieved_chunk_ids: list[str],
    positive_chunk_id: str
) -> int:
    """
    정답 chunk_id가 Top-5 안에 있으면 1, 없으면 0.
    """
    return int(positive_chunk_id in retrieved_chunk_ids[:5])


def calculate_mrr(
    retrieved_chunk_ids: list[str],
    positive_chunk_id: str
) -> float:
    """
    정답 chunk_id가 등장한 순위의 reciprocal rank를 계산한다.
    """
    for idx, chunk_id in enumerate(retrieved_chunk_ids, start=1):
        if chunk_id == positive_chunk_id:
            return 1 / idx

    return 0.0