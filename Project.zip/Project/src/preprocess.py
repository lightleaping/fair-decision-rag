import json
import re
from pathlib import Path

import pandas as pd


def load_chunks(file_path: str) -> list[dict]:
    """
    JSON, JSONL, CSV 형식의 chunk 데이터를 불러온다.
    """
    path = Path(file_path)

    if not path.exists():
        raise FileNotFoundError(f"데이터 파일을 찾을 수 없습니다: {file_path}")

    if path.suffix == ".json":
        with open(path, "r", encoding="utf-8") as f:
            data = json.load(f)

        if isinstance(data, list):
            return data

        if isinstance(data, dict):
            if "chunks" in data:
                return data["chunks"]
            if "data" in data:
                return data["data"]

        raise ValueError("JSON 구조에서 chunk 리스트를 찾을 수 없습니다.")

    if path.suffix == ".jsonl":
        chunks = []
        with open(path, "r", encoding="utf-8") as f:
            for line in f:
                if line.strip():
                    chunks.append(json.loads(line))
        return chunks

    if path.suffix == ".csv":
        df = pd.read_csv(path)
        return df.to_dict("records")

    raise ValueError(f"지원하지 않는 파일 형식입니다: {path.suffix}")


def clean_text(text: str) -> str:
    """
    법률 문서의 핵심 정보는 유지하면서 불필요한 공백만 정리한다.
    """
    if text is None:
        return ""

    text = str(text)
    text = text.replace("\n", " ")
    text = text.replace("\t", " ")
    text = re.sub(r"\s+", " ", text)
    return text.strip()


def detect_section_type(text: str, current_section: str | None = None) -> str:
    """
    section_type이 이미 있으면 사용하고,
    없으면 텍스트 패턴으로 추정한다.
    """
    if current_section and str(current_section).strip():
        return str(current_section).strip()

    text = text or ""

    if "주문" in text:
        return "주문"
    if "이유" in text:
        return "이유"
    if "별지" in text:
        return "별지"
    if "결론" in text:
        return "결론"
    if "과징금" in text:
        return "주문/별지"

    return "기타"


def normalize_chunks(chunks: list[dict]) -> list[dict]:
    """
    chunk마다 chunk_id, chunk_text, section_type을 표준화한다.
    """
    normalized = []

    for idx, chunk in enumerate(chunks):
        raw_text = (
            chunk.get("chunk_text")
            or chunk.get("text")
            or chunk.get("content")
            or ""
        )

        cleaned_text = clean_text(raw_text)

        chunk_id = chunk.get("chunk_id") or f"chunk_{idx:05d}"

        section_type = detect_section_type(
            text=cleaned_text,
            current_section=chunk.get("section_type")
        )

        normalized.append({
            **chunk,
            "chunk_id": chunk_id,
            "chunk_text": cleaned_text,
            "section_type": section_type,
        })

    return normalized


def check_chunk_integrity(chunks: list[dict]) -> dict:
    """
    chunk_id 누락, 중복, 빈 텍스트를 검사한다.
    """
    chunk_ids = [chunk.get("chunk_id") for chunk in chunks]

    missing_chunk_id = sum(1 for chunk_id in chunk_ids if not chunk_id)
    duplicated_chunk_id = len(chunk_ids) - len(set(chunk_ids))

    empty_text = sum(
        1 for chunk in chunks
        if not str(chunk.get("chunk_text", "")).strip()
    )

    return {
        "total_chunks": len(chunks),
        "missing_chunk_id": missing_chunk_id,
        "duplicated_chunk_id": duplicated_chunk_id,
        "empty_text": empty_text,
    }


def get_section_statistics(chunks: list[dict]) -> dict:
    """
    section_type별 chunk 개수를 계산한다.
    """
    stats = {}

    for chunk in chunks:
        section_type = chunk.get("section_type", "기타")
        stats[section_type] = stats.get(section_type, 0) + 1

    return stats